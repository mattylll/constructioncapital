# B001-R30-V01: Fewer homes. A bigger share.

Visual adaptation of B001-R30, by Matt Lenzie / Construction Capital.
Original analysis page: https://constructioncapital.co.uk/market-reports/housing-output-fell-regional-share-rose-2024-25

The four-row infographic-data.csv is derived from the parent study's annual-concentration.csv.
Shares = group count / England count * 100. Percentage change = (new / old - 1) * 100.
Counts: 2023/24 revised, 2024/25 provisional, MHCLG Table 118 (20 November 2025 edition).

Graphic and original analysis: CC BY 4.0, https://creativecommons.org/licenses/by/4.0/
Source statistics: Crown copyright, Open Government Licence v3.0.
The parent research archive contains the original workbook, CSVs, definitions and standard-library reproduction script.
The graphic renderer needs Python 3, Pillow, and Arial/Georgia TTF fonts at the paths stated in build_infographic.py.
On another operating system, adjust FONTS to the equivalent font directory. No numerical result depends on fonts.

This is the same underlying study, not an independent validation of it.
