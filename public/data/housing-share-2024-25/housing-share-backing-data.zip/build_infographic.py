from pathlib import Path
import csv, html, json, hashlib
from PIL import Image, ImageDraw, ImageFont

P = Path(__file__).resolve().parent
SOURCE_FINDINGS = P/'data/findings.json'
if not SOURCE_FINDINGS.exists():
    SOURCE_FINDINGS = P.parent/'B001-R30-flipsnack/data/findings.json'
D = json.loads(SOURCE_FINDINGS.read_text())
A, B = D['annual'][-2:]
SLUG = 'housing-output-fell-regional-share-rose-2024-25'
SOURCE = 'https://constructioncapital.co.uk/market-reports/' + SLUG
GOV = 'https://www.gov.uk/government/statistical-data-sets/live-tables-on-net-supply-of-housing'
BACKING = 'https://drive.google.com/file/d/1nTEcluv2MFcHYN_mxwWfdVFYBL06WoLq/view'
W,H=1200,1800
NAVY='#132D46'; GOLD='#B38834'; TEAL='#087D83'; BG='#F7F4ED'; MUTED='#496075'; LINE='#D5DDD9'; RED='#A84438'
im=Image.new('RGB',(W,H),BG); draw=ImageDraw.Draw(im)
svg=[f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}" role="img" aria-labelledby="title desc"><title id="title">Fewer homes. A bigger share.</title><desc id="desc">England net additions fell 5.8% between 2023/24 and 2024/25. South East, London and East of England additions fell 5.7%, so their combined share rose by 0.06 percentage points.</desc>']
FONTS=Path('/System/Library/Fonts/Supplemental')
def rect(x,y,w,h,color):
    draw.rectangle((x,y,x+w,y+h),fill=color)
    svg.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" fill="{color}"/>')
def text(s,x,y,size=28,color=NAVY,bold=False,serif=False):
    name=('Georgia' if serif else 'Arial')+(' Bold' if bold else '')+'.ttf'
    font=ImageFont.truetype(str(FONTS/name),size)
    assert draw.textbbox((x,y),s,font=font,anchor='lt')[2] <= W-45, (s,x,size)
    draw.text((x,y),s,fill=color,font=font,anchor='lt')
    svg.append(f'<text x="{x}" y="{y}" dominant-baseline="text-before-edge" font-family="{"Georgia" if serif else "Arial"}" font-size="{size}" font-weight="{"700" if bold else "400"}" fill="{color}">{html.escape(s)}</text>')
def line(y):rect(70,y,1060,2,LINE)
def number(n):return f'{n:,}'
change_eng=(B['england_net_additions']/A['england_net_additions']-1)*100
change_group=(B['fixed_group_net_additions']/A['fixed_group_net_additions']-1)*100
delta=(B['fixed_group_net_additions']/B['england_net_additions']-A['fixed_group_net_additions']/A['england_net_additions'])*100
assert round(change_eng,1)==-5.8 and round(change_group,1)==-5.7 and round(delta,2)==.06
rect(0,0,W,H,BG);rect(0,0,W,16,GOLD)
text('CONSTRUCTION CAPITAL',70,53,27,bold=True)
text('HOUSING DATA, EXPLAINED',734,57,21,color=MUTED)
text('Fewer homes.',70,124,84,bold=True,serif=True)
text('A bigger share.',70,220,84,bold=True,serif=True)
text('How three regions gained a little national share',70,331,33)
text('even as their combined housing additions fell.',70,378,33)
rect(70,444,1060,74,NAVY)
text('ENGLAND  •  2023/24 TO 2024/25',96,465,27,color='white',bold=True)
text('01',70,559,25,color=GOLD,bold=True)
text('Output fell in both comparisons',134,552,34,bold=True)
text('Net additional dwellings. All bars use the same zero baseline and scale.',70,607,23,color=MUTED)
barx=240;barmax=700
for label,key,y,color in [('England','england_net_additions',664,NAVY),('South East + London + East of England','fixed_group_net_additions',891,TEAL)]:
    text(label,70,y,29,bold=True)
    for i,(a,year) in enumerate([(A,'2023/24'),(B,'2024/25')]):
        yy=y+55+i*64
        text(year,70,yy+8,26,color=MUTED)
        bw=a[key]/250000*barmax
        rect(barx,yy,bw,42,color)
        text(number(a[key]),barx+bw+14,yy+7,27,bold=True)
    ch=change_eng if key=='england_net_additions' else change_group
    text(f'{ch:.1f}% year on year',760,y,25,color=RED,bold=True)
text('0',233,1097,19,color=MUTED)
text('125,000',barx+barmax/2-35,1097,19,color=MUTED)
text('250,000',barx+barmax-35,1097,19,color=MUTED)
rect(barx,1084,barmax,1,LINE)
line(1146)
text('02',70,1186,25,color=GOLD,bold=True)
text('Their national share edged up',134,1179,34,bold=True)
text('44.79%',70,1245,74,color=TEAL,bold=True)
text('→',444,1254,62,color=MUTED)
text('44.85%',586,1245,74,color=TEAL,bold=True)
text('2023/24',74,1332,23,color=MUTED)
text('2024/25',590,1332,23,color=MUTED)
text('+0.06 percentage points',70,1391,31,bold=True)
text('England’s total fell slightly faster than the group’s total.',70,1443,27)
text('A rising share alone does not mean more homes were added.',70,1487,27)
line(1551)
text('Source: MHCLG Live Table 118, 20 November 2025 edition.',70,1584,24,bold=True)
text('2023/24 revised; 2024/25 provisional. Net additions include new',70,1625,23,color=MUTED)
text('building and other gains, less losses. Shares use unrounded counts.',70,1662,23,color=MUTED)
text('Matt Lenzie  |  Construction Capital  |  25 September 2026',70,1719,22)
text('constructioncapital.co.uk/market-reports',70,1758,21,color=TEAL)
svg.append('</svg>')
(P/'housing-share-infographic.svg').write_text(''.join(svg))
im.save(P/'housing-share-infographic.png',optimize=True)
im.save(P/'housing-share-infographic.jpg',quality=92,optimize=True)
alt='England net additional dwellings fell from 221,409 in 2023/24 to 208,600 in 2024/25, down 5.8%. South East, London and East of England fell from 99,175 to 93,562, down 5.7%. Their combined national share rose from 44.79% to 44.85%, a 0.06 percentage point increase, because the national total fell slightly faster.'
(P/'alt-text.txt').write_text(alt+'\n')
with (P/'infographic-data.csv').open('w',newline='') as f:
    writer=csv.writer(f);writer.writerow(['geography','financial_year','net_additional_dwellings','share_of_england_pct','status'])
    for a,stat in [(A,'revised'),(B,'provisional')]:
        for geo,key,share in [('England','england_net_additions',100),('South East + London + East of England','fixed_group_net_additions',a['fixed_group_share_pct'])]:
            writer.writerow([geo,a['financial_year'],a[key],share,stat])
facts={'research_id':'B001-R30-V01','derived_from':'B001-R30','england_change_pct':change_eng,'group_change_pct':change_group,'share_change_pp':delta,'source_page_intended':SOURCE,'source_vintage':'2025-11-20','image_dimensions':[W,H],'alt':alt,'sha256_png':hashlib.sha256((P/'housing-share-infographic.png').read_bytes()).hexdigest()}
(P/'facts.json').write_text(json.dumps(facts,indent=2)+'\n')
# This is an exact, editable-source Canva import, not an AI redrawing of the values.
doc=f'''<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Fewer homes. A bigger share. | Construction Capital</title><style>*{{box-sizing:border-box}}body{{margin:0;background:{BG};color:{NAVY};font-family:Arial,sans-serif}}main{{max-width:1200px;margin:auto}}svg{{display:block;width:100%;height:auto}}.links{{padding:36px 6%;font-size:22px;line-height:1.6;border-top:2px solid {LINE}}}a{{color:{TEAL}}}.links p{{margin:10px 0}}</style></head><body><main data-document-role="page" data-label="Fewer homes. A bigger share.">{''.join(svg)}<div class="links"><p><strong>Follow the evidence</strong></p><p><a href="{SOURCE}">Read the Construction Capital analysis</a> · <a href="{BACKING}">Download the backing data and code</a></p><p><a href="{GOV}">Original MHCLG housing supply tables</a></p><p>For the composition of additional supply, see our <a href="https://anyflip.com/solvf/iwye/">Beyond new build report</a>. These are related analyses by the same author, not independent endorsements.</p><p>Graphic and analysis: Matt Lenzie, Construction Capital. Reuse under <a href="https://creativecommons.org/licenses/by/4.0/">CC BY 4.0</a>, with attribution. Source statistics: Crown copyright, <a href="https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/">Open Government Licence v3.0</a>.</p></div></main></body></html>'''
(P/'canva-infographic.html').write_text(doc)
print(json.dumps(facts,indent=2));print('Created:',P/'canva-infographic.html');print('PNG bytes:',(P/'housing-share-infographic.png').stat().st_size)
